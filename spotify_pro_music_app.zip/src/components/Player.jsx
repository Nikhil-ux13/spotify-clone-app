import React, { useState, useRef } from 'react';

const Player = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef(null);

  const togglePlay = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="bg-zinc-800 p-4 flex justify-between items-center">
      <span>Now Playing: Sample Track</span>
      <div>
        <button onClick={togglePlay} className="bg-green-500 px-4 py-2 rounded text-white">
          {isPlaying ? 'Pause' : 'Play'}
        </button>
        <audio ref={audioRef} src="/music/sample.mp3" />
      </div>
    </div>
  );
};

export default Player;