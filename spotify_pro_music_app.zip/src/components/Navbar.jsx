import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav className="bg-zinc-800 p-4 flex justify-between">
    <Link to="/" className="text-xl font-bold text-green-400">Spotify Pro</Link>
    <div className="space-x-4">
      <Link to="/" className="hover:text-green-300">Home</Link>
      <Link to="/search" className="hover:text-green-300">Search</Link>
    </div>
  </nav>
);

export default Navbar;