import React, { useState } from 'react';

const Search = () => {
  const [query, setQuery] = useState("");

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-2">Search Music</h2>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search for songs or artists..."
        className="w-full p-2 rounded bg-zinc-700 text-white"
      />
    </div>
  );
};

export default Search;