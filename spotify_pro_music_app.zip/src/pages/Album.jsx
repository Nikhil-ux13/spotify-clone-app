import React from 'react';
import { useParams } from 'react-router-dom';

const Album = () => {
  const { id } = useParams();

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Album ID: {id}</h2>
      <p>This page will display the album details and song list.</p>
    </div>
  );
};

export default Album;