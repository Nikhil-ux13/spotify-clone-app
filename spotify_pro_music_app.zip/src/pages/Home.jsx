import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Featured Albums</h1>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Link to="/album/1" className="bg-zinc-700 p-4 rounded hover:bg-zinc-600">
        <h2 className="text-xl">Chill Beats</h2>
        <p>Lo-fi, Jazzhop</p>
      </Link>
      <Link to="/album/2" className="bg-zinc-700 p-4 rounded hover:bg-zinc-600">
        <h2 className="text-xl">Workout Hits</h2>
        <p>EDM, Pop</p>
      </Link>
    </div>
  </div>
);

export default Home;